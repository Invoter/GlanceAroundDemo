//
//  ViewController.m
//  Demo
//
//  Created by Invoter丶C on 15/7/31.
//  Copyright (c) 2015年 IT. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.runView.center = self.view.center;
    self.runView.layer.borderColor = [[UIColor redColor] CGColor];
    self.runView.clipsToBounds = YES;
    self.runView.layer.borderWidth = 2;
    
    imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"0.jpg"]];
    imageView.center = CGPointMake(40, 40);
    imageView.bounds = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    [self.runView addSubview:imageView];
    
    point_x = 2;
    point_y = 3;
    [NSTimer scheduledTimerWithTimeInterval:0.05 target:self selector:@selector(ballRun) userInfo:nil repeats:YES];
    
    
}
- (void)ballRun{
    
    self.runView.center = CGPointMake(self.runView.center.x+point_x, self.runView.center.y+point_y);
    imageView.center = CGPointMake(imageView.center.x-point_x, imageView.center.y-point_y);
    
    if (self.runView.center.x<0||self.runView.center.x>320) {
        point_x = -point_x;
    }
    if (self.runView.center.y<0||self.runView.center.y>self.view.frame.size.height) {
        point_y = -point_y;
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
