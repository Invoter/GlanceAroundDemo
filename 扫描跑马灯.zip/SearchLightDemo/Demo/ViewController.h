//
//  ViewController.h
//  Demo
//
//  Created by Invoter丶C on 15/7/31.
//  Copyright (c) 2015年 IT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    UIImageView    *imageView;
    float                       point_x;
    float                       point_y;
}
@property (weak, nonatomic) IBOutlet UIView *runView;



@end

